import React from 'react'
import Layout from './components/layout/Layout.jsx'
import './styles/style.min.css'
const App = () => {
  return (
      <Layout/>
  )
}

export default App