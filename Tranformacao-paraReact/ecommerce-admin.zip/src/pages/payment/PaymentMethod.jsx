import React from 'react'

const PaymentMethod = () => {
  return (
    <div>
      
    </div>
  )
}

export default PaymentMethod