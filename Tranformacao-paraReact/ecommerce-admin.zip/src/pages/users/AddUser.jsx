import React from 'react'

const AddUser = () => {
  return (
    <div>
      
    </div>
  )
}

export default AddUser