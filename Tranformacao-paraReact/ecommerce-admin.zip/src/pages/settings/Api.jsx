import React from 'react'

const Api = () => {
	return (
		<div>
			Api
		</div>
	)
}

export default Api