import React from 'react'

const Email = () => {
	return (
		<div>
			Email
		</div>
	)
}

export default Email