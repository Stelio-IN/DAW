import React from 'react'

const CronJob = () => {
	return (
		<div>
			CronJob
		</div>
	)
}

export default CronJob