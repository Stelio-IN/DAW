import React from 'react'

const ManageVenue = () => {
	return (
		<div>
			ManageVenue
		</div>
	)
}

export default ManageVenue