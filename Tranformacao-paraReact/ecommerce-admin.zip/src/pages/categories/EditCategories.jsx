import React from 'react'

const EditCategories = () => {
  return (
    <div>
      EditCategories
    </div>
  )
}

export default EditCategories