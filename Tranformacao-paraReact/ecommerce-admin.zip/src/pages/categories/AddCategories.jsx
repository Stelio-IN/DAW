import React from 'react'

const AddCategories = () => {
  return (
    <div>
      AddCategories
    </div>
  )
}

export default AddCategories